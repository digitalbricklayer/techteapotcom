$Common::global::gVersion = "Cricket version 1.0.5 (2004-03-28)";

$Common::global::gVersion =~ s/[!]!VERSION![!]/devel/;
1;
